package ru.javarush.lesson25.game;

public interface Unit {
    void go();
}
