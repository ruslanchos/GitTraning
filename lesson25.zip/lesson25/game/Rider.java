package ru.javarush.lesson25.game;

public class Rider implements Unit{
    @Override
    public void go() {
        System.out.println("Rider go...");
    }
}
