package ru.javarush.lesson25.game;

public class MagicUnit extends AbstractUnit{
    protected MagicUnit(Unit unit) {
        super(unit);
    }

    @Override
    protected void afterGo() {
        System.out.println("magic added...");
    }
}
