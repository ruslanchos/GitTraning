package ru.javarush.lesson25.game;

public class GameRunner {
    public static void main(String[] args) {
        MagicUnit unit = new MagicUnit(new ProtectedUnit(new Ork()));
        unit.go();

    }
}
