package ru.javarush.lesson25.game;

public class ProtectedUnit extends AbstractUnit{
    protected ProtectedUnit(Unit unit) {
        super(unit);
    }

    @Override
    protected void afterGo() {
        System.out.println("protect added...");
    }
}
