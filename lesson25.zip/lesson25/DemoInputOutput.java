package ru.javarush.lesson25;

import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class DemoInputOutput {

    public static final String DATA_BIN = "data.bin";
    public static final String DATA_TXT = "data.txt";

    public static void main(String[] args) {
        byte[] bytes = saveInts();
        List<Integer> list = readInts(bytes);
        outToConsole(list);
        outToFile(list, DATA_TXT);
    }

    private static void outToFile(List<Integer> list, String dataTxt) {
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(DATA_TXT,true))) {
            double sum = 0;
            for (Integer integer : list) {
                sum += integer;
                printWriter.print(integer + " ");
            }
            printWriter.printf("%navg=%f%n", sum / list.size());
        } catch (IOException e) {
            throw new AppException(e);
        }
    }

    private static void outToConsole(List<Integer> list) {
        double sum = 0;
        for (Integer integer : list) {
            sum += integer;
            System.out.print(integer + " ");
        }
        System.out.printf("%navg=%f%n", sum / list.size());
    }

    @NotNull
    private static List<Integer> readInts(byte[] bytes) {
        List<Integer> list = new ArrayList<>();
        try (DataInputStream dataInputStream = new DataInputStream(
                new ByteArrayInputStream(bytes)
        )) {
            while (dataInputStream.available() > 0) {
                int readInt = dataInputStream.readInt();
                list.add(readInt);
            }
        } catch (IOException e) {
            throw new AppException(e);
        }
        return list;
    }

    private static byte[] saveInts() {
        ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
        try (DataOutputStream dataOutputStream = new DataOutputStream(
                arrayOutputStream
        )) {
            for (int i = 0; i < 10; i++) {
                ThreadLocalRandom random = ThreadLocalRandom.current();
                int value = random.nextInt(1000);
                dataOutputStream.writeInt(value);
            }
        } catch (IOException e) {
            throw new AppException(e);
        }
        byte[] bytes = arrayOutputStream.toByteArray();
        return bytes;
    }
}
